<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Router CURD</title>    
    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>asset/css/responsive.bootstrap4.min.css">  
</head>
<body>
    <div class="container">
        <div class="row"><div>Routing Details</div></div>
        <div id="listing_section">
            <div class="row">
                <div><button name="btn_list_add" id="btn_list_add" class="btn btn-secondary">Add New</button></div>
            </div>
            <div class="row">
                <table class="table table-striped table-bordered dt-responsive " id="RouterListing" style="width: 100%">
                    <thead>
                        <tr>
                            <th>SAP ID</th>
                            <th>Host Name</th>
                            <th>loopbck (Ipv4)</th>
                            <th>Mac Address</th>
                            <th style="text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="listRecords">    
                       
                    </tbody>
                </table>
            </div>
        </div>
        <div id="add_section" class="d-none">
            <div class="row">
                <div><button name="btn_list" id="btn_list" class="btn btn-secondary">View List</button></div>
            </div>
            <div class="row">
                <table>
                    <tr>
                        <td>SAP ID</td>
                        <td><input type="text" name="sap_id" id="sap_id" value="" placeholder="SAP ID" maxlength="18"></td>
                    </tr>
                    <tr>
                        <td>Host Name</td>
                        <td><input type="text" name="host_name" id="host_name" value="" placeholder="Host Name" maxlength="14"></td>
                    </tr>
                    <tr>
                        <td>loopbck (Ipv4)</td>
                        <td><input type="text" name="loopback" id="loopback" value="" placeholder="loopbck (Ipv4)" maxlength="18"></td>
                    </tr>
                    <tr>
                        <td>Mac Address</td>
                        <td><input type="text" name="mac_address" id="mac_address" value="" placeholder="Mac Address" maxlength="17"></td>
                    </tr>
                    <tr>
                        <td colspan="2"><button type="submit" class="btn btn-primary" id="save_router_btn">Save</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <button type="reset" name="reset_router_btn" id="reset_router_btn"  class="btn btn-danger ">Reset</button></td>
                    </tr>
                </table>
            </div>            
        </div>
        <div id="edit_section" class="d-none">
            <div class="row">
                <div><button name="btn_list" id="btn_list" class="btn btn-secondary">View List</button></div>
            </div>
            <div class="row">
                <table>
                    <tr>
                        <td>SAP ID</td>
                        <td><input type="text" name="sap_id" id="edit_sap_id" value="" placeholder="SAP ID" maxlength="18"></td>
                    </tr>
                    <tr>
                        <td>Host Name</td>
                        <td><input type="text" name="host_name" id="edit_host_name" value="" placeholder="Host Name" maxlength="14"></td>
                    </tr>
                    <tr>
                        <td>loopbck (Ipv4)</td>
                        <td><input type="text" name="loopback" id="edit_loopback" value="" placeholder="loopbck (Ipv4)" maxlength="18"></td>
                    </tr>
                    <tr>
                        <td>Mac Address</td>
                        <td><input type="text" name="mac_address" id="edit_mac_address" value="" placeholder="Mac Address" maxlength="17"></td>
                    </tr>
                    <tr>
                        <input type="hidden" name="update_id" id="update_id" value="">
                        <td colspan="2"><button type="submit" class="btn btn-primary" id="update_router_btn">Update</button></td>
                    </tr>
                </table>
            </div>            
        </div>
    </div>
    <script src="<?php echo base_url();?>asset/js/jquery-3.5.1.min.js"></script>    
    <script src="<?php echo base_url();?>asset/js/bootstrap.min.js"></script>

    <script type="text/javascript" src="<?php echo base_url();?>asset/js/datatable/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>asset/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>asset/js/datatable/dataTables.responsive.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>asset/js/datatable/responsive.bootstrap4.min.js"></script>

    
    <script type="text/javascript">
        $(document).ready(function() {

            $('#btn_list_add').on('click',function(){
                //console.log("hiii.");
                $('#add_section').removeClass('d-none');
                $('#listing_section').addClass('d-none');
                $('#edit_section').addClass('d-none');

            });

            $('#btn_list').on('click',function(){
                $('#add_section').addClass('d-none');
                $('#listing_section').removeClass('d-none');
                $('#edit_section').addClass('d-none');

            });

            listRouts();//listing on load

            // list all
            function listRouts(){
                $.ajax({
                    type  : 'get',
                    url   : 'router/show',
                    async : false,
                    dataType : 'json',
                    success : function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                            html += '<tr id="'+data[i].id+'">'+
                                    '<td>'+data[i].sap_id+'</td>'+
                                    '<td>'+data[i].host_name+'</td>'+
                                    '<td>'+data[i].loopback+'</td>'+
                                    '<td>'+data[i].mac_address+'</td>'+    
                                    '<td style="text-align:right;">'+
                                        '<a href="javascript:void(0);" class="btn btn-info btn-sm editRecord" data-id="'+data[i].id+'">Edit</a>'+' '+
                                        '<button class="btn btn-danger btn-sm deleteRouter" data-id="'+data[i].id+'">Delete</button>'+
                                    '</td>'+
                                    '</tr>';
                        }
                        $('#listRecords').html(html);    
                       //   console.log(data);               
                    }

                });
            }

            $('#RouterListing').DataTable({"order": [] });//datatable

            // save new record
            $('#save_router_btn').on('click',function(){
                //console.log("innnn");
                var sap_id = $('#sap_id').val();
                var host_name = $('#host_name').val();
                var loopback = $('#loopback').val();
                var mac_address = $('#mac_address').val();
                $.ajax({
                    type : "POST",
                    url  : "router/save",
                    dataType : "JSON",
                    data : {sap_id:sap_id, host_name:host_name, loopback:loopback, mac_address:mac_address},
                    success: function(data){
                        $('#reset_router_btn').trigger("click");
                        $('#btn_list').trigger("click");
                        listRouts();
                    }
                });
                //return false;
            });

            //reset
            $('#reset_router_btn').on('click',function(){
                $('#sap_id').val("");
                $('#host_name').val("");
                $('#loopback').val("");
                $('#mac_address').val("");
            });

            // delete  record
             $('#listRecords').on('click','.deleteRouter',function(){
                //console.log($(this).attr('data-id'));
                var id = $(this).attr('data-id');
                $.ajax({
                    type : "POST",
                    url  : "router/delete",
                    dataType : "JSON",  
                    data : {id:id},
                    success: function(data){
                        listRouts();
                    }
                });
               // return false;
            });

             $('#listRecords').on('click','.editRecord',function(){
                $('#add_section').addClass('d-none');
                $('#listing_section').addClass('d-none');
                $('#edit_section').removeClass('d-none');

                var id = $(this).attr('data-id');

                $.ajax({
                    type  : 'post',
                    url   : 'router/getdetails',
                    data : {id:id},
                    dataType : 'json',                    
                    success : function(data){
                        var html = '';
                        var i;
                        for(i=0; i<data.length; i++){
                            $('#edit_sap_id').val(data[i].sap_id);
                            $('#edit_host_name').val(data[i].host_name);
                            $('#edit_loopback').val(data[i].loopback);
                            $('#edit_mac_address').val(data[i].mac_address);
                            $('#update_id').val(data[i].id);
                        }
                       // $('#listRecords').html(html);    
                       //   console.log(data);               
                    }

                });

            });

              // save new record
            $('#update_router_btn').on('click',function(){
                //console.log("innnn");
                var id = $('#update_id').val();
                var sap_id = $('#edit_sap_id').val();
                var host_name = $('#edit_host_name').val();
                var loopback = $('#edit_loopback').val();
                var mac_address = $('#edit_mac_address').val();
                $.ajax({
                    type : "POST",
                    url  : "router/saverecord",
                    dataType : "JSON",
                    data : {sap_id:sap_id, host_name:host_name, loopback:loopback, mac_address:mac_address,id:id},
                    success: function(data){
                        $('#reset_router_btn').trigger("click");
                        $('#btn_list').trigger("click");
                        listRouts();
                    }
                });
                //return false;
            });

        });
    </script>
</body>
</html>