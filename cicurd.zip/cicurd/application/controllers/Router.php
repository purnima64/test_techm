<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Router extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('RouterModel','routerM');
	}

	public function index()
	{
		$this->load->view('list');
	}

	public function show()
	{
		$data = $this->routerM->getRouterList();
		echo json_encode($data);
	}
	
	public function save()
	{
		$data = $this->routerM->saveRouter();
		echo json_encode($data);
	}

	public function delete()
	{
		$data = $this->routerM->deleteRouter();
		echo json_encode($data);
	}

	public function getdetails()
	{
		$data = $this->routerM->getRecord();
		echo json_encode($data);
	}

	public function saverecord()
	{
		$data = $this->routerM->saveRecord();
		echo json_encode($data);
	}


	public function save_records()
	{
		echo "hiii";
	}
}
