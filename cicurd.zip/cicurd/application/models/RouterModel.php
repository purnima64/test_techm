<?php
class RouterModel extends CI_Model{

	function getRouterList(){
		$res = $this->db->get('router_details');
		return $res->result();
	}

	function saveRouter(){
		$data = array(				
				'sap_id' 		=> $this->input->post('sap_id'), 
				'host_name' 	=> $this->input->post('host_name'), 
				'loopback' 		=> $this->input->post('loopback'), 
				'mac_address' 	=> $this->input->post('mac_address'), 
			);
		$result=$this->db->insert('router_details',$data);
		return $result;
	}

	function getRecord(){
		$res = $this->db->get_where('router_details', array('id'=> $this->input->post('id')));
		return $res->result();
	}

	function saveRecord(){
		$id = $this->input->post('id');
		$sap_id = $this->input->post('sap_id');
		$host_name = $this->input->post('host_name');
		$loopback = $this->input->post('loopback');
		$mac_address = $this->input->post('mac_address');

		$this->db->set('sap_id', $sap_id);
		$this->db->set('host_name', $host_name);
		$this->db->set('loopback', $loopback);
		$this->db->set('mac_address', $mac_address);
		$this->db->where('id', $id);
		
		$result=$this->db->update('router_details');
		return $result;	
	}

	function deleteRouter(){
		$id=$this->input->post('id');
		$this->db->where('id', $id);
		$result=$this->db->delete('router_details');
		return $result;
	}	
}